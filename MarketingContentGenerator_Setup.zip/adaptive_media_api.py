#!/usr/bin/env python3
"""
ADAPTIVE MEDIA GENERATION API
Auto-detects device/platform and generates optimized media
"""

from fastapi import Request
from pydantic import BaseModel
from typing import Optional, List
import json

# Media format specifications for different platforms/devices
MEDIA_FORMATS = {
    # Social Media Platforms
    "instagram_story": {
        "aspect_ratio": "9:16",
        "resolution": "1080p",
        "width": 1080,
        "height": 1920,
        "description": "Instagram/Facebook Story (vertical mobile)"
    },
    "instagram_feed": {
        "aspect_ratio": "1:1",
        "resolution": "1080p",
        "width": 1080,
        "height": 1080,
        "description": "Instagram Feed Post (square)"
    },
    "instagram_portrait": {
        "aspect_ratio": "4:5",
        "resolution": "1080p",
        "width": 1080,
        "height": 1350,
        "description": "Instagram Portrait Post"
    },
    "tiktok": {
        "aspect_ratio": "9:16",
        "resolution": "1080p",
        "width": 1080,
        "height": 1920,
        "description": "TikTok Video (vertical)"
    },
    "youtube_video": {
        "aspect_ratio": "16:9",
        "resolution": "1080p",
        "width": 1920,
        "height": 1080,
        "description": "YouTube Video (horizontal)"
    },
    "youtube_short": {
        "aspect_ratio": "9:16",
        "resolution": "1080p",
        "width": 1080,
        "height": 1920,
        "description": "YouTube Shorts (vertical)"
    },
    "twitter_post": {
        "aspect_ratio": "16:9",
        "resolution": "1080p",
        "width": 1280,
        "height": 720,
        "description": "Twitter/X Post"
    },
    "linkedin_post": {
        "aspect_ratio": "16:9",
        "resolution": "1080p",
        "width": 1280,
        "height": 720,
        "description": "LinkedIn Post"
    },
    
    # Device-Optimized
    "mobile_vertical": {
        "aspect_ratio": "9:16",
        "resolution": "720p",
        "width": 720,
        "height": 1280,
        "description": "Mobile phone (vertical orientation)"
    },
    "mobile_horizontal": {
        "aspect_ratio": "16:9",
        "resolution": "720p",
        "width": 1280,
        "height": 720,
        "description": "Mobile phone (horizontal orientation)"
    },
    "tablet": {
        "aspect_ratio": "4:3",
        "resolution": "1080p",
        "width": 1440,
        "height": 1080,
        "description": "Tablet (iPad-style)"
    },
    "desktop": {
        "aspect_ratio": "16:9",
        "resolution": "1080p",
        "width": 1920,
        "height": 1080,
        "description": "Desktop/Laptop"
    },
    "desktop_4k": {
        "aspect_ratio": "16:9",
        "resolution": "1080p",  # Veo limited to 1080p max
        "width": 1920,
        "height": 1080,
        "description": "4K Desktop (served as 1080p due to API limits)"
    },
    "ultrawide": {
        "aspect_ratio": "21:9",
        "resolution": "1080p",
        "width": 2560,
        "height": 1080,
        "description": "Ultrawide monitor"
    },
    
    # Ad Formats
    "banner_leaderboard": {
        "aspect_ratio": "728:90",
        "resolution": "720p",
        "width": 728,
        "height": 90,
        "description": "Leaderboard Banner Ad"
    },
    "banner_mobile": {
        "aspect_ratio": "320:50",
        "resolution": "720p",
        "width": 640,
        "height": 100,
        "description": "Mobile Banner Ad"
    },
    "banner_square": {
        "aspect_ratio": "1:1",
        "resolution": "720p",
        "width": 600,
        "height": 600,
        "description": "Square Banner Ad"
    }
}

# Device detection rules
DEVICE_RULES = {
    "mobile": {
        "max_width": 767,
        "default_formats": ["mobile_vertical", "instagram_story", "tiktok"],
        "aspect_ratio": "9:16",
        "resolution": "720p"
    },
    "tablet": {
        "min_width": 768,
        "max_width": 1024,
        "default_formats": ["tablet", "instagram_feed"],
        "aspect_ratio": "4:3",
        "resolution": "1080p"
    },
    "desktop": {
        "min_width": 1025,
        "default_formats": ["desktop", "youtube_video"],
        "aspect_ratio": "16:9",
        "resolution": "1080p"
    }
}

class AdaptiveMediaRequest(BaseModel):
    campaign_name: str
    brand_name: str
    description: str
    
    # Auto-detection mode
    auto_detect: bool = True
    
    # Manual format selection (overrides auto-detect)
    formats: Optional[List[str]] = None
    
    # Client device info (for better detection)
    screen_width: Optional[int] = None
    screen_height: Optional[int] = None
    device_pixel_ratio: Optional[float] = 1.0
    connection_type: Optional[str] = None  # "4g", "wifi", "slow-2g", etc.
    
    # Content settings
    video_type: str = "standard"  # short, standard, extended
    model: str = "veo"  # veo or runway

class MultiFormatResponse(BaseModel):
    campaign_name: str
    brand_name: str
    detected_device: Optional[str]
    formats_generated: dict
    recommendations: dict


def detect_device_type(request: Request, screen_width: Optional[int] = None) -> str:
    """Detect device type from user agent and screen width"""
    
    user_agent = request.headers.get("user-agent", "").lower()
    
    # Check screen width first if provided
    if screen_width:
        if screen_width <= 767:
            return "mobile"
        elif screen_width <= 1024:
            return "tablet"
        else:
            return "desktop"
    
    # Fallback to user agent parsing
    mobile_keywords = ["iphone", "android", "mobile", "webos", "blackberry"]
    tablet_keywords = ["ipad", "tablet", "kindle"]
    
    if any(keyword in user_agent for keyword in mobile_keywords):
        return "mobile"
    elif any(keyword in user_agent for keyword in tablet_keywords):
        return "tablet"
    else:
        return "desktop"


def select_optimal_format(device_type: str, connection: Optional[str] = None) -> dict:
    """Select optimal format based on device and connection"""
    
    rules = DEVICE_RULES.get(device_type, DEVICE_RULES["desktop"])
    
    # Adjust for slow connections
    if connection in ["slow-2g", "2g", "3g"]:
        # Use lower resolution for slow connections
        return {
            "aspect_ratio": rules["aspect_ratio"],
            "resolution": "720p",  # Force 720p for slow connections
            "note": "Resolution reduced due to slow connection"
        }
    
    return {
        "aspect_ratio": rules["aspect_ratio"],
        "resolution": rules["resolution"]
    }


async def generate_for_format(
    format_name: str,
    campaign_name: str,
    brand_name: str,
    description: str,
    video_type: str,
    model: str
) -> dict:
    """Generate video for a specific format"""
    from video_mcp_server import generate_video
    
    format_spec = MEDIA_FORMATS.get(format_name)
    if not format_spec:
        return {"error": f"Unknown format: {format_name}"}
    
    # Generate video with format specifications
    result_json = await generate_video(
        campaign_name=campaign_name,
        brand_name=brand_name,
        video_type=video_type,
        description=f"{description}\n\nOptimized for: {format_spec['description']}",
        resolution=format_spec["resolution"],
        aspect_ratio=format_spec["aspect_ratio"],
        model=model
    )
    
    result = json.loads(result_json)
    result["format_name"] = format_name
    result["format_specs"] = format_spec
    
    return result


# Add these endpoints to your FastAPI app:

@app.post("/generate/adaptive")
async def generate_adaptive_media(request: Request, data: AdaptiveMediaRequest):
    """
    Generate media optimized for detected device/platform
    Auto-detects device and creates optimal versions
    """
    
    results = {
        "campaign_name": data.campaign_name,
        "brand_name": data.brand_name,
        "formats": {}
    }
    
    if data.auto_detect:
        # Detect device type
        device_type = detect_device_type(request, data.screen_width)
        results["detected_device"] = device_type
        
        # Get optimal format
        optimal = select_optimal_format(device_type, data.connection_type)
        results["optimal_settings"] = optimal
        
        # Get recommended formats for this device
        formats_to_generate = DEVICE_RULES[device_type]["default_formats"]
        
    elif data.formats:
        # Use manually specified formats
        formats_to_generate = data.formats
        results["detected_device"] = "manual_selection"
    else:
        # Default to desktop
        formats_to_generate = ["desktop"]
        results["detected_device"] = "default"
    
    # Generate videos for all selected formats
    for format_name in formats_to_generate:
        result = await generate_for_format(
            format_name=format_name,
            campaign_name=data.campaign_name,
            brand_name=data.brand_name,
            description=data.description,
            video_type=data.video_type,
            model=data.model
        )
        
        results["formats"][format_name] = result
    
    return results


@app.get("/formats/list")
async def list_available_formats():
    """List all available media formats with specifications"""
    return {
        "total_formats": len(MEDIA_FORMATS),
        "formats": MEDIA_FORMATS,
        "categories": {
            "social_media": [k for k in MEDIA_FORMATS.keys() if any(s in k for s in ["instagram", "tiktok", "youtube", "twitter", "linkedin"])],
            "devices": [k for k in MEDIA_FORMATS.keys() if any(s in k for s in ["mobile", "tablet", "desktop", "ultrawide"])],
            "advertising": [k for k in MEDIA_FORMATS.keys() if "banner" in k]
        }
    }


@app.post("/generate/campaign-bundle")
async def generate_campaign_bundle(
    campaign_name: str,
    brand_name: str,
    description: str,
    bundle_type: str = "full"  # "full", "social", "devices", "ads"
):
    """
    Generate a complete bundle of videos for a campaign
    
    Bundle types:
    - full: All formats (expensive!)
    - social: Social media platforms only
    - devices: Device-optimized versions only
    - ads: Advertising formats only
    """
    
    bundles = {
        "social": ["instagram_story", "instagram_feed", "tiktok", "youtube_video", "youtube_short"],
        "devices": ["mobile_vertical", "tablet", "desktop"],
        "ads": ["banner_leaderboard", "banner_mobile", "banner_square"],
        "full": list(MEDIA_FORMATS.keys())
    }
    
    formats = bundles.get(bundle_type, bundles["devices"])
    
    results = {}
    for format_name in formats:
        result = await generate_for_format(
            format_name=format_name,
            campaign_name=campaign_name,
            brand_name=brand_name,
            description=description,
            video_type="standard",
            model="veo"
        )
        results[format_name] = result
    
    return {
        "campaign": campaign_name,
        "bundle_type": bundle_type,
        "formats_generated": len(results),
        "results": results
    }


# Example usage with client-side detection:
"""
<script>
async function generateAdaptiveVideo(campaignData) {
    const response = await fetch('/generate/adaptive', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            ...campaignData,
            auto_detect: true,
            screen_width: window.innerWidth,
            screen_height: window.innerHeight,
            device_pixel_ratio: window.devicePixelRatio,
            connection_type: navigator.connection?.effectiveType || 'unknown'
        })
    });
    
    return response.json();
}

// Call it
generateAdaptiveVideo({
    campaign_name: "Summer Sale 2024",
    brand_name: "MyBrand",
    description: "Show beach products"
}).then(result => {
    console.log("Generated formats:", result.formats);
});
</script>
"""