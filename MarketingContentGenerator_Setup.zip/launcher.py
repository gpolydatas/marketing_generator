
import os
import sys
import subprocess
import webbrowser
import time

# Add Python to path
script_dir = os.path.dirname(os.path.abspath(__file__))
python_dir = os.path.join(script_dir, "python")
python_exe = os.path.join(python_dir, "python.exe")

# Install packages on first run
pip_installed = os.path.join(python_dir, ".pip_installed")
if not os.path.exists(pip_installed):
    print("First run setup...")
    subprocess.run([python_exe, os.path.join(script_dir, "get-pip.py")], check=True)
    subprocess.run([python_exe, "-m", "pip", "install", "-r", "requirements.txt"], check=True)
    open(pip_installed, "w").close()

os.makedirs("outputs", exist_ok=True)

print("Starting server...")
server = subprocess.Popen([python_exe, "fastapi_server.py"], 
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd=script_dir)
time.sleep(2)

print("Starting UI...")
streamlit = subprocess.Popen([python_exe, "-m", "streamlit", "run", "streamlit_app.py",
    "--server.port=8501", "--server.headless=true", "--browser.gatherUsageStats=false"],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd=script_dir)
time.sleep(3)

webbrowser.open("http://localhost:8501")
print("\nRunning at http://localhost:8501")
print("Press Ctrl+C to stop")

try:
    streamlit.wait()
except KeyboardInterrupt:
    pass
finally:
    server.terminate()
    streamlit.terminate()
